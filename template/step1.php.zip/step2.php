<style>
@media screen and (max-width:767px)
.testi1 {

    top: -150px!important;
    position: relative!important;
}
</style>
<style>
.testi1 {

    top: -150px!important;
    position: relative!important;
}
</style>


<div class="container step2">
    <div class="row">
        <div class="col-md-12 steps">
            <div class="col-md-4 col-xs-4 one-step done ">
                <i class="fa fa-check statuss" aria-hidden="true"></i>
                <h3 class="statuss"><?php echo $etaps1; ?></h3>
            </div>
            <div class="col-md-4 col-xs-4 one-step active">
                <i class="fa fa-home" aria-hidden="true"></i>
                <h3><?php echo $etaps2; ?></h3>
            </div>
            <div class="col-md-4 col-xs-4 one-step">
                <i class="fa fa-list-alt" aria-hidden="true"></i>
                <h3><?php echo $etaps3; ?></h3>
            </div>
        </div>

    </div>

    <div class="row topdd">
        <div class="col-md-12 ">
            <div class="tit_eval_resul set2">
                <h1><?php echo $titre_2; ?></h1>
            </div>
        </div>
        <div class="col-md-12 ">
            <div class="col-md-6 no-mobile-padding">
                <div id="map"></div>
                
        <div class="testi1">
                      <?php require "testimonial.php";
        ?>
            </div>
            </div>

            <?php
      if (get_post_meta($post->ID, 'formID', true)) {
        $formID = get_post_meta($post->ID, 'formID', true);
      } else {
        $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);
        $cf7Forms = get_posts($args);
        $formID = $cf7Forms[0]->ID;
      }

      ?>

            <div class="col-md-6 no-mobile-padding forny">
                <h3><?php echo $sous_titre_2; ?></h3>
                <br />
                <input type="hidden" name="unite" value="<?php echo (isset($_POST['unite'])) ? $_POST['unite'] : '';  ?>" />

                <?php echo do_shortcode('[contact-form-7 id=' . $formID . ' title="Formulaire de contact 1" html_id="msform"]'); ?>
                <sup><?php echo $politique_2; ?></sup>
            </div>
        </div>

    </div>
</div>


<script>
jQuery(document).ready(function() {
    jQuery("input[type='tel']").mask('(000) 000-0000');

})
// Initialize and add the map
function initMap() {
    // The location of Uluru
    var uluru = {
        lat: <?php echo $lat; ?>,
        lng: <?php echo $long; ?>
    };
    // The map, centered at Uluru
    var map = new google.maps.Map(
        document.getElementById('map'), {
            zoom: 18,
            center: uluru,
            mapTypeId: google.maps.MapTypeId.SATELLITE
        });
    // The marker, positioned at Uluru
    var marker = new google.maps.Marker({
        position: uluru,
        map: map,
        /* label: {
           color: 'white',
           fontWeight: 'bold',
           text: '<?php echo $address1; ?>',
         },*/
        icon: {
            size: new google.maps.Size(22, 40),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(11, 40),
            labelOrigin: new google.maps.Point(40, 33)
        },


    });
}
</script>
<!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
<!-- PROD KEY AIzaSyAXhbCXalRIlmMJ3Kfxl9jtRzWZ_LJfrDc-->
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo WP_ENV_GOOGLE_API_2 ?>&callback=initMap">
</script>