<div class="container">
    <div class="row">
        <div class="col-md-12 steps">
            <div class="col-md-4 col-xs-4 one-step done ">
                <i class="fa fa-check statuss" aria-hidden="true"></i>
                <h3 class="statuss"><?php echo $etaps1; ?></h3>
            </div>
            <div class="col-md-4 col-xs-4 one-step done">
                <i class="fa fa-check statuss" aria-hidden="true"></i>
                <h3 class="statuss"><?php echo $etaps2; ?></h3>
            </div>
            <div class="col-md-4 col-xs-4 one-step active">
                <i class="fa fa-list-alt" aria-hidden="true"></i>
                <h3><?php echo $etaps3; ?></h3>
            </div>
        </div>
    </div>
    <div class="row topdd ">
        <div class="tit_eval_resul set2">
            <h1>
                <?php echo $titre_3; ?></h1> <br />
            <h3><?php echo $texte_3; ?></h3>

            <?php if (isset($_SESSION['email'])) { ?>
                <br />
                <p><?php echo $label_courriel ?> : <b class="red"><?php echo $_SESSION['email'] ?></b><br /><?php echo $label_telephone ?> : <b class="red"><?php echo $_SESSION['telephone'] ?></b> </p>
                <p><?php echo $pas_bon_courriel; ?></p>
                <button type="submit" onclick="history.back()" name="next" class="red h2-white-text btn btn-danger btn-step-3 next" value="<?php echo $label_button_3 ?>"><?php echo $label_button_3 ?></button>
                </form>
            <?php } ?>

        </div>

        <?php
        require_once "testimonial.php";
        ?>
    </div>


</div>
<?php
